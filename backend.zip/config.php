<?php
	session_start();
	define('BASE','http://localhost/backend/');
	date_default_timezone_set("America/Sao_Paulo");
?>