<div class="container" style='margin-top:100px;'>
	<div class="row">
		<div class="col-md-12">
			<center>
				<i class="fa fa-truck" style="font-size:96px;"></i>
				<p>Carga anúnciada com sucesso!</p>
				<a href='<?php echo BASE; ?>profile'>Voltar para o perfil</a>
			</center>
		</div>
	</div>
</div>