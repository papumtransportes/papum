<div class="container" style='margin-top:100px;'>
	<div class="row">
		<div class="col-lg-12 ">
			<div class="element col-sm-6">
				<div class="view project_descr center">
					<h3><a href="<?php echo BASE; ?>cliente"><span class="glyphicon glyphicon-user" style="font-size:96px;"></span> <br>Cliente</a></h3>
					<ul>
					</ul>
				</div>
			</div>

			<div class="element  col-sm-6">
				<div class="view project_descr center" >
					<h3><a href="<?php echo BASE; ?>transportadora"><i class="fa fa-truck" style="font-size:96px;"></i><br>Transportador</a></h3>
					<ul>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>