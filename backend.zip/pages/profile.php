<?php
	if(!isset($_SESSION['id_user'])){
		echo "<h2>ERRO 200</h2><p>Você não tem permissão para acessar essa página</p>";
		exit;
	}
?>
<div class='submenu'>
	<div class='container'>
		<div class='menu'>
			<a href="fretes">Meus Fretes</a>
			<a href="fretes">Chat</a>
			<a href="fretes">Histórico</a>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<form action="" id='filter' method="post" enctype="multipart/form-data">
				<select id="filtros">
					<option value="">Filtros</option>
					<option value="categoria">Categoria</option>
					<option value="subcategoria">Subcategoria</option>
					<option value="data">Data</option>
				</select>
				<input type="search" placeholder="Pesquisar cargas..."/>
				<input type="submit" value="Pesquisar"/>
				<a class='anunciar' href='categoria'>Fazer anúncio</a>
			</form>
			<div class='anuncios' style='margin-top:20px;'>
			</div>
		</div>
	</div>
</div>