<hr/>
<div class='container'>
	<div class='row'>
		<div class='col-md-12'>
			<h2>E-mail enviado</h2>
			<p>Enviamos um email para <?php echo $_SESSION['forgot_email']; ?></p>
			<p>Confira sua caixa de entrada para alterar a sua senha</p>
		</div>
	</div>
</div>
<hr/>