<hr/>
<form action='' id='forgot' method='post' enctype='multipart/form-data'>
	<div class='container'>
		<div class='row'>
			<div class='col-md-12'>
				<label>Digite seu e-mail</label>
				<input type='text' name='email' id='email' class='form-control' placeholder='Digite seu email' required="required"/><br>
			</div>
			<div class='col-md-12'>
				<input type='submit' class='btn btn-default' value='Enviar'/>
				<a href='login'>Voltar</a>
			</div>
		</div>
	</div>
</form>
<hr/>