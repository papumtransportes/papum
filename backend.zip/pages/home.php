
		<div class="container">
			<div class="row">
				<div class="col-md-4 project">
					<!--<h3 id="counter">0</h3>-->
					<h4>N�s ajudamos voc� </h4>
					<p>Precisa de algo r�pido? voc� pode contar com a gente para arrumar tudo pra voc�. </p>
				</div>
				<div class="col-md-4 project">
					<!--<h3 id="counter1">0</h3>-->
					<h4>Tudo � um clique de dist�ncia</h4>
					<p>Passos simpes para achar o melhor modo de transportar seus pertences.</p>
				</div>
				<div class="col-md-4 project">
					<!--<h3 id="counter2" style="margin-left: 20px;">0</h3>-->
					<h4 style="margin-left: 20px;">Escolha seu pre�o</h4>
					<p>Quanto vale seu frete? aqui voc� pode escolher o valor que deseja pagar. </p>
				</div>
			</div>
		</div>
		<div class='searchbox'>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<form action="" id="search" method="" enctype="multipart/form-data">
							<input type="search" id='query' placeholder="Digite sua pesquisa..." required="required"/>
							<input type="submit" value="Pesquisar"/>
							<label><strong>Exemplos:</strong> Mudancas, Moveis, Alimentos</label>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 cBusiness">
					<h3>O melhor modo de achar transportadoras</h3>
					<h4>Voc� pode acessar nosso site de qualquer lugar, seu smartphone, tablet, notebook...</h4>
					
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 centPic">
					<img class="img-responsive"  src="<?php echo BASE; ?>images/home/responsive.png"/>
				</div>
			</div>
		</div>   
    </div>
    
    <!--about start-->    
    
    <div id="about">
    	<div class="line2">
			<div class="container">
				<div class="row Fresh">
					<div class="col-md-4 Des">
						<i class="fa fa-heart"></i>
						<h4>R�pido</h4>
						
					</div>
					<div class="col-md-4 Ver">
						<i class="fa fa-cog"></i>
						<h4  >Econ�mico</h4>
						
					</div>
					<div class="col-md-4 Fully">
						<i class="fa fa-tablet"></i>
						<h4 >Seguro</h4>
						
					</div>		
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 wwa">
					<span name="about" ></span>
					<h3>Nossas Avalia��es</h3>
					
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row team">
				<div class="col-md-4 b1">
						<img class="img-responsive" src="<?php echo BASE; ?>images/picTeam/picT5.jpg">
						<h4>Camila Souza</h4>
					
						<p>Voc� pode conseguir um valor que esteja no seu or�amento</p>
						<!--<ul>
							<li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
							<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							<li><a href="#"><i class="fa fa-twitter" ></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>
						</ul>-->
				</div>
			
			
				<div class="col-md-4">
						<img class="img-responsive" src="<?php echo BASE; ?>images/picTeam/picT2.png">
						<h4>Ricardo Nascimento</h4>
						<p>Sem mais d�vidas na hora de contratar algu�m.</p>
						
				</div>
		
			
				<div class="col-md-4 b3">
						<img class="img-responsive" src="<?php echo BASE; ?>images/picTeam/picT3.png">
						<h4>Ana Eduarda</h4>
						<p>Tudo � feito no conforto do seu lar.</p>
					
				</div>
			</div>
		</div>
		
		<div class="container">
			<div class="row">
				<div class="col-md-12 hr1">
					<hr/>
				</div>
			</div>
		</div>		
		
		<!--<div class="container">
			<div class="row">
				<div class="col-md-3 bar">
					<div class="progB chart" data-percent="64"  data-animate="3500">
						<div class="chart chart-content">
							<div class="percentage" data-percent="64">
							  <span class="percent">64</span>
							</div>
						</div>
					</div>
					<div class="textP">
						<h3>WordPress</h3>
						<p>Nulla consectetur ornare nibh, a auctor <br/>mauris scelerisque eu proin nec urna quis. </p>
					</div>
				</div>
				<div class="col-md-3 bar">
					<div class="progB chart" data-percent="22"  data-animate="3500">
						<div class="chart chart-content">
							<div class="percentage" data-percent="22">
							  <span class="percent">22</span>
							</div>
						</div>
					</div>
					<div class="textP">
						<h3>HTML5</h3>
						<p>Nulla consectetur ornare nibh, a auctor <br/>mauris scelerisque eu proin nec urna quis. </p>
					</div>
				</div>
				<div class="col-md-3 bar ">
					<div class="progB chart" data-percent="84"  data-animate="3500">
						<div class="chart chart-content">
							<div class="percentage" data-percent="22">
							  <span class="percent">84</span>
							</div>
						</div>
					</div>
					<div class="textP">
						<h3>CSS3</h3>
						<p>Nulla consectetur ornare nibh, a auctor <br/>mauris scelerisque eu proin nec urna quis. </p>
					</div>
				</div>
				<div class="col-md-3 bar ">
					<div class="progB chart" data-percent="45"  data-animate="3500">
						<div class="chart chart-content">
							<div class="percentage" data-percent="45">
							  <span class="percent">45</span>
							</div>
						</div>
					</div>
					<div class="textP">
						<h3>Woocommerce</h3>
						<p>Nulla consectetur ornare nibh, a auctor <br/>mauris scelerisque eu proin nec urna quis. </p>
					</div>
				</div>
			</div>
		</div>	
		
		
		<div class="container">
			<div class="row aboutUs">
				<div class="col-md-12 ">
					<h3>What Our Customers Say About Us?</h3>
				</div>
			</div>
		</div>-->
		
		<!--<div style="position: relative;">
		
			<div class="container">
				<div class="row about">
					<div class="col-md-6">
						<div class="about1">
						<img class="pic1Ab" src="images/picAbout/aboutP1.png">
							<h3>Anna Smith, Company Inc.</h3>
							<p>Transportadores confi�veis, avaliados pelos nossos clientes. Voc� ainda pode converssar com eles pelo nosso site</p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="about2">
						<img class="pic2Ab" src="images/picAbout/aboutP2.png">
							<h3>John Doe, Company Inc.</h3>
							<p>Consectetur ornare nibh, a auctor mauris scelerisque eu proin nec urna quis justo, adipiscing auctor, ut auctor feugiat fermentum nec quisque eget pharetra, felis et venenatis aliquam, nulla nisi lobortis elit, ac luctus.</p>
						</div>
					</div>
				</div>
			</div>-->
		
			<div class="horL"></div>
		
			<div class="container">
				<div class="row about">
					<div class="col-md-6">
						<div class="about1">
						<img class="pic1Ab" src="<?php echo BASE; ?>images/picAbout/aboutP3.png">
							<h3>Marcos Silva</h3>
							<p> Quando pesquisei pela primeira vez um transporte, achei os pre�os muito elevados, aqui eu consegui fazer o transporte do meu carro, pagando um valor muito menor e com uma transportadora muito boa.</p>
						</div>
					</div>
					<div class="col-md-6">
						<div class="about2">
						<img class="pic2Ab" src="<?php echo BASE; ?>images/picAbout/aboutP1.png">
							<h3>Sarah Ribeiro</h3>
							<p>Site muito bom! Procurei por muito tempo, antes de conhecer o site, um bom transportador para fazer minha mudan�a, e n�o achava nenhum. Quando encontrava n�o sentia nenhuma seguran�a. Agora fa�a tudo aqui. </p>
						</div>
					</div>
				</div>
			</div>
		
		</div>
    </div>
    <!--project start-->    
    <div id="project">    	
		<div class="line3">
			<div class="container">
				<div id="project1" ></div>
				<div class="row Ama">
					<div class="col-md-12">
					<span name="projects" id="projectss"></span>
					<h3 >Categorias de cargas</h3>
					<p>Escolha uma de nossas categorias e anuncie j� seu frete.
					</div>
				</div>
			</div>
		</div>          
    
    
       <div class="container">
		
		<div class="row">
			<!-- filter_block -->
				<div id="options" class="col-md-12" style="text-align: center;">	
					<ul id="filter" class="option-set" data-option-key="filter">
						<li><a class="selected" href="#filter" data-option-value="*" class="current">Todos</a></li>
						<li><a href="#filter" data-option-value=".mudancas">Mudan�as</a></li>
						<li><a href="#filter" data-option-value=".artigos">Artigos Dom�sticos</a></li>
						<li><a href="#filter" data-option-value=".cargas">Cargas</a></li>
						<li><a href="#filter" data-option-value=".veiculosBarcos">Ve�culos e Barcos</a></li>
						<li><a href="#filter" data-option-value=".outros">Outros</a></li>
					</ul>
				</div><!-- //filter_block -->
		
		
		
			<div class="portfolio_block columns3   pretty" data-animated="fadeIn">	
			
					<!-- Mudan�as -->
					<div class="element col-sm-4  gall artigos">
						<a class="plS" href="images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/moveis.jpg" alt="Apartamento de 2 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/artigos_domesticos.html">M�veis</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					
					<div class="element col-sm-4  gall cargas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/carga2.jpg" alt="pic2 Gallery"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="#">Carga Fracionada</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					
					<div class="element col-sm-4  gall veiculosBarcos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic3.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/motos.jpg" alt="pic3 Gallery"/>
						</a>
						<div class="view project_descr ">
							<h3><a href="#">Motos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>400</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>124</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall mudancas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/box.jpg" alt="Apartamento de 3 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/mudancas.html">Apartamento de 3 quartos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall mudancas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/box.jpg" alt="Casa de 3 qaurtos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/mudancas.html">Casa de 3 quartos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall mudancas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/box.jpg" alt="Casa de 4 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/mudancas.html">Casa de 4 quartos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					
					
					
					<!-- Mudan�as -->
					<div class="element col-sm-4  gall artigos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/tv.jpg" alt="Apartamento de 2 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/artigos_domesticos.html">Eletrodom�sticos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall artigos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/antiguidades.jpg" alt="Apartamento de 2 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/artigos_domesticos.html">Antiguidades</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall artigos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/frageis.jpg" alt="Apartamento de 2 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/artigos_domesticos.html">Fr�geis</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall mudancas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic2.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/box.jpg" alt="Apartamento de 2 quartos"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="<?php echo BASE; ?>/html/subcategoria/mudancas.html">Apartamento de 2 quartos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>369</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>86</a></li>
							</ul>
						</div>
					</div>					
					
					<div class="element col-sm-4  gall veiculosBarcos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic3.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/barcos.jpg" alt="pic3 Gallery"/>
						</a>
						<div class="view project_descr ">
							<h3><a href="#">Barcos</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>400</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>124</a></li>
							</ul>
						</div>
					</div>
		
		
					
					<div class="element col-sm-4  gall  outros">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic4.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/bebidas.jpg" alt="pic1 Gallery"/>
						</a>
						<div class="view project_descr ">
							<h3><a href="#">Bebias</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>480</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>95</a></li>
							</ul>
						</div>
					</div>
					<div class="element col-sm-4  gall  veiculosBarcos">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic5.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/carros.jpg" alt="pic1 Gallery"/>
						</a>
						<div class="view project_descr center">
							<h3><a href="#">Carros</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>215</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>14</a></li>
							</ul>
						</div>
					</div>
					
					<div class="element col-sm-4   gall cargas">
						<a class="plS" href="<?php echo BASE; ?>images/prettyPhotoImages/pic7.jpg" rel="prettyPhoto[gallery2]">
							<img class="img-responsive picsGall" src="<?php echo BASE; ?>images/home/categorias/carga1.jpg" alt="pic1 Gallery"/>
						</a>
						<div class="view project_descr ">
							<h3><a href="#">Carga Completa</a></h3>
							<ul>
								<li><i class="fa fa-eye"></i>440</li>
								<li><a  class="heart" href="#"><i class="fa-heart-o"></i>35</a></li>
							</ul>
						</div>
					</div>
										
			</div>
							
		<div class="col-md-12 cBtn  lb" style="text-align: center;">
			<ul class="load_more_cont ">
				<li class="dowbload btn_load_more">
					<a href="javascript:void(0);" >
						<i class="fa fa-arrow-down"></i>Carregar mais				
				</li>
			</ul>
		</div>
			
		</div>
			
			<!-- Bot�o Carregar Mais
			<script type="text/javascript">
				jQuery(window).load(function(){
					items_set = [
					
						{category : 'cargas', lika_count : '77', view_count : '234', src : 'images/prettyPhotoImages/pic9.jpg', title : 'Foil Mini Badges', content : '' },
						
						{category : 'artigos', lika_count : '45', view_count : '100', src : 'images/prettyPhotoImages/pic7.jpg', title : 'Darko � Business Card Mock Up', content : '' },
						
						{category : 'outros', lika_count : '22', view_count : '140', src : 'images/prettyPhotoImages/pic8.jpg', title : 'Woody Poster Text Effect', content : '' }
						

					];
					jQuery('.portfolio_block').portfolio_addon({
						type : 1, // 2-4 columns simple portfolio
						load_count : 3,
						
						items : items_set
					});
					$('#container').isotope({
					  animationOptions: {
						 duration: 900,
						 queue: false
					   }
					});
				});
			</script>-->
		</div>
    </div>    